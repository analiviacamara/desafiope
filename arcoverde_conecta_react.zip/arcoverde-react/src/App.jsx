import React, { useEffect, useMemo, useState } from 'react';

const KEY = 'arcoverde-conecta-react-v1';
const setores = {
  'Iluminação pública': 'Iluminação / Obras',
  'Limpeza urbana': 'Limpeza urbana',
  'Buracos e pavimentação': 'Obras e infraestrutura',
  'Água e saneamento': 'Saneamento / setor competente',
  'Saúde': 'Saúde',
  'Outros': 'Triagem municipal',
};
const statuses = ['Pendente', 'Em andamento', 'Concluída'];
const emptyForm = { titulo:'', categoria:'', bairro:'', endereco:'', descricao:'', urgencia:'1', alcance:'1', responsavel:'', prazo:'', foto:'' };
const now = () => new Date().toISOString();
const formatDate = value => new Date(value).toLocaleString('pt-BR');
const score = d => Number(d.urgencia) * 10 + (Number(d.alcance) >= 100 ? 10 : Number(d.alcance) >= 20 ? 5 : 0);
const prioridade = d => score(d) >= 35 ? 'Alta' : score(d) >= 20 ? 'Média' : 'Baixa';
const todayLocal = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
function initialDemandas() {
  try { const saved = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(saved) ? saved : []; }
  catch { return []; }
}
function exportCSV(demandas) {
  const fields = ['id','titulo','categoria','bairro','endereco','descricao','urgencia','alcance','setor','responsavel','prazo','status','criado'];
  const quote = value => '"' + String(value ?? '').replace(/^[=+@\-\t\r]/, "'$&").replace(/"/g, '""') + '"';
  const lines = [fields.join(';'), ...demandas.map(d => fields.map(k => quote(d[k])).join(';'))];
  const url = URL.createObjectURL(new Blob(['\ufeff' + lines.join('\r\n')], {type:'text/csv;charset=utf-8'}));
  const a = document.createElement('a'); a.href = url; a.download = 'demandas_arcoverde.csv'; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export default function App() {
  const [demandas, setDemandas] = useState(initialDemandas);
  const [form, setForm] = useState(emptyForm);
  const [busca, setBusca] = useState('');
  const [filtro, setFiltro] = useState('');
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');
  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(demandas)); setErro(''); }
    catch { setErro('Não foi possível salvar os registros. Verifique o espaço do navegador ou reduza o tamanho das fotos.'); }
  }, [demandas]);
  const stats = useMemo(() => ({
    total: demandas.length,
    pendentes: demandas.filter(d => d.status === 'Pendente').length,
    andamento: demandas.filter(d => d.status === 'Em andamento').length,
    concluidas: demandas.filter(d => d.status === 'Concluída').length,
  }), [demandas]);
  const filtradas = useMemo(() => demandas.filter(d =>
    (!filtro || d.status === filtro) &&
    [d.id,d.titulo,d.bairro,d.categoria,d.endereco].join(' ').toLocaleLowerCase('pt-BR').includes(busca.toLocaleLowerCase('pt-BR'))
  ).sort((a,b) => Number(a.status === 'Concluída') - Number(b.status === 'Concluída') || score(b) - score(a) || b.criado.localeCompare(a.criado)), [demandas,busca,filtro]);
  const change = e => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  async function onPhoto(e) {
    const file = e.target.files?.[0];
    if (!file) { setForm(prev => ({...prev,foto:''})); return; }
    if (file.size > 1024*1024 || !file.type.startsWith('image/')) { setErro('Selecione uma imagem de até 1 MB.'); e.target.value=''; return; }
    const reader = new FileReader();
    reader.onload = () => { setForm(prev => ({...prev,foto:String(reader.result)})); setErro(''); };
    reader.onerror = () => setErro('Não foi possível ler a imagem.');
    reader.readAsDataURL(file);
  }
  function cadastrar(e) {
    e.preventDefault(); setErro(''); setSucesso('');
    if (!form.titulo.trim() || !form.categoria || !form.bairro.trim() || !form.endereco.trim() || !form.descricao.trim() || !Number.isFinite(Number(form.alcance)) || Number(form.alcance) < 1) {
      setErro('Preencha os campos obrigatórios corretamente.'); return;
    }
    const criado = now();
    const id = `ARC-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2,5).toUpperCase()}`;
    const demanda = {...form, id, urgencia:Number(form.urgencia), alcance:Number(form.alcance), setor:setores[form.categoria], status:'Pendente', criado, historico:[`${formatDate(criado)}: demanda registrada e encaminhada para ${setores[form.categoria]}`]};
    setDemandas(prev => [...prev,demanda]); setForm(emptyForm); e.currentTarget.reset(); setSucesso(`Demanda cadastrada! Protocolo: ${id}`);
  }
  function updateStatus(id, status) {
    setDemandas(prev => prev.map(d => d.id === id ? {...d,status,historico:[...d.historico,`${formatDate(now())}: status alterado para ${status}`]} : d));
  }
  function addProvidencia(id) {
    const msg = window.prompt('Descreva a providência adotada:');
    if (!msg?.trim()) return;
    setDemandas(prev => prev.map(d => d.id === id ? {...d,historico:[...d.historico,`${formatDate(now())}: ${msg.trim().slice(0,500)}`]} : d));
  }
  return <>
    <header><div className="header-inner"><h1>🏙️ Arcoverde Conecta</h1><p>Central de registro, priorização e acompanhamento de serviços públicos</p></div></header>
    <main>
      <section className="stats" aria-label="Indicadores">
        {[['Total de demandas',stats.total],['Pendentes',stats.pendentes],['Em andamento',stats.andamento],['Concluídas',stats.concluidas]].map(([label,value]) => <div className="stat" key={label}><span>{label}</span><strong>{value}</strong></div>)}
      </section>
      {erro && <p className="alert error" role="alert">{erro}</p>}
      {sucesso && <p className="alert success" role="status">{sucesso}</p>}
      <div className="layout">
        <section className="panel"><h2>➕ Nova demanda</h2>
          <form onSubmit={cadastrar}>
            <label htmlFor="titulo">Título do problema *</label><input id="titulo" name="titulo" value={form.titulo} onChange={change} maxLength="100" required placeholder="Ex.: Poste apagado na rua"/>
            <label htmlFor="categoria">Categoria *</label><select id="categoria" name="categoria" value={form.categoria} onChange={change} required><option value="">Selecione</option>{Object.keys(setores).map(s => <option key={s}>{s}</option>)}</select>
            <label htmlFor="bairro">Bairro ou comunidade *</label><input id="bairro" name="bairro" value={form.bairro} onChange={change} required maxLength="90" placeholder="Ex.: Centro"/>
            <label htmlFor="endereco">Endereço ou referência *</label><input id="endereco" name="endereco" value={form.endereco} onChange={change} required maxLength="160" placeholder="Rua, número ou ponto de referência"/>
            <label htmlFor="descricao">Descrição *</label><textarea id="descricao" name="descricao" value={form.descricao} onChange={change} required maxLength="1200" placeholder="Descreva o problema"/>
            <label htmlFor="urgencia">Urgência *</label><select id="urgencia" name="urgencia" value={form.urgencia} onChange={change}><option value="1">Baixa</option><option value="2">Média</option><option value="3">Alta</option></select>
            <label htmlFor="alcance">Pessoas afetadas (estimativa) *</label><input id="alcance" name="alcance" type="number" min="1" max="1000000" value={form.alcance} onChange={change} required/>
            <label htmlFor="responsavel">Responsável (opcional)</label><input id="responsavel" name="responsavel" value={form.responsavel} onChange={change} maxLength="100" placeholder="Equipe ou servidor"/>
            <label htmlFor="prazo">Prazo previsto (opcional)</label><input id="prazo" name="prazo" type="date" value={form.prazo} onChange={change}/>
            <label htmlFor="foto">Fotografia (opcional, até 1 MB)</label><input id="foto" name="foto" type="file" accept="image/*" onChange={onPhoto}/>
            <button className="full" type="submit">Cadastrar demanda</button>
          </form><p className="notice">Demonstração: os dados ficam salvos somente neste navegador. Não utilize dados pessoais reais.</p>
        </section>
        <section className="panel"><h2>📋 Painel de demandas</h2>
          <div className="toolbar"><input aria-label="Pesquisar demandas" placeholder="Buscar por protocolo, bairro, título..." value={busca} onChange={e=>setBusca(e.target.value)}/><select aria-label="Filtrar por status" value={filtro} onChange={e=>setFiltro(e.target.value)}><option value="">Todos os status</option>{statuses.map(s=><option key={s}>{s}</option>)}</select><button className="secondary" type="button" onClick={()=>exportCSV(demandas)}>Exportar CSV</button></div>
          {!filtradas.length ? <p className="empty">Nenhuma demanda encontrada.</p> : filtradas.map(d => <article className="item" key={d.id}>
            <div className="item-head"><div><h3>{d.titulo}</h3><p className="meta">{d.id} • {d.categoria} • {d.bairro}</p></div><span className={`pill ${prioridade(d)==='Alta'?'alta':prioridade(d)==='Média'?'media':'baixa'}`}>Prioridade {prioridade(d)}</span></div>
            <p className="desc">{d.descricao}</p>
            <p className="detail">📍 {d.endereco}</p><p className="detail">🏢 Setor: {d.setor}</p><p className="detail">👤 Responsável: {d.responsavel || 'Não atribuído'}</p><p className="detail">👥 Pessoas afetadas: {d.alcance}</p><p className="detail">📅 Prazo: {d.prazo ? d.prazo.split('-').reverse().join('/') : 'Não definido'}</p><p className="detail">🕒 Criada em: {formatDate(d.criado)}</p>
            {d.prazo && d.status !== 'Concluída' && d.prazo < todayLocal() && <span className="pill alta">Prazo vencido</span>}
            {d.foto && <img src={d.foto} alt="Foto anexada à demanda" className="photo"/>}
            <div className="actions"><select aria-label={`Status da demanda ${d.id}`} value={d.status} onChange={e=>updateStatus(d.id,e.target.value)}>{statuses.map(s=><option key={s}>{s}</option>)}</select><button type="button" className="secondary" onClick={()=>addProvidencia(d.id)}>Registrar providência</button></div>
            <details className="history"><summary>Histórico ({d.historico.length} registros)</summary>{d.historico.map((h,i)=><p key={i}>{h}</p>)}</details>
          </article>)}
        </section>
      </div>
    </main>
    <footer>Protótipo acadêmico independente • Desafios Day 2026 • Arcoverde, Pernambuco</footer>
  </>;
}
