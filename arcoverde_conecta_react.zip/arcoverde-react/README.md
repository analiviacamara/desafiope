# Arcoverde Conecta — React + Vite

Protótipo de gestão de demandas municipais. Feito com React (JSX, useState, useEffect, useMemo), JavaScript e CSS.

## Como executar

1. Instale o Node.js (versão 18 ou superior).
2. Abra a pasta `arcoverde-react` no VS Code.
3. No terminal, execute:

```bash
npm install
npm run dev
```

4. Abra o endereço local exibido no terminal (geralmente `http://localhost:5173`).

## Gerar versão de publicação

```bash
npm run build
```

A pasta `dist/` poderá ser publicada em serviços de hospedagem estática.

## Funcionalidades

- Cadastro de demandas, foto opcional, protocolo e histórico
- Prioridade automática por urgência e alcance
- Encaminhamento sugerido por categoria
- Status, busca, filtro, prazos vencidos e indicadores
- Exportação CSV
- Persistência no `localStorage` do navegador

**Atenção:** é um protótipo, sem servidor, autenticação ou banco de dados compartilhado. Não insira dados pessoais reais. A pontuação de prioridade e os nomes de setores são demonstrativos.
